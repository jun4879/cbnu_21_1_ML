%%I dedicate this work To my son "BERGHOUT Loukmane"close all;
clear all;
clc
addpath('RBM');
%% load training data
% prepare training data
pathname        = uigetdir;
allfiles        = dir(fullfile(pathname,'*.jpg'));
xtr=[];       % initialize training inputs
gamma=[70 70];% size of each image
for i=1:size(allfiles,1)    
x=imread([pathname '\\' allfiles(i).name]);
x=imresize(x,gamma);
x=rgb2gray(x);
x=double(x);
xtr=[xtr; x];% training set building
end
%% Training Options
Options.max_itera=100;            % maximum number of learning itterations
Options.N_gs=60;                  % number of gibbs samplling steps
Options.Nneurons=gamma(1);        % number of neurons in the hidden layer
Options.eps=0.01;                 % learning rate
Options.Sz_mb=10;                 % size if mini-batch of data
%% Training process 
net=RBM_TB(xtr,Options);% training
net.Tr_acc
%% Prediction
xp=imread('Test.jpg');
xp=imresize(xp,gamma);
xp1=rgb2gray(xp);
xp=double(xp1);
[y]=RBM_RECONSTRUCT(net,xp);
%% Illustration 
subplot(221)
imshow(y)
title('regenerated input')
subplot(222)
imshow(xp1);
title('original input')
subplot(2,2,3:4)
plot(1:length(net.hist),net.hist,'LineWidth',2)
xlabel('number of iterations')
ylabel('RMSE of training')
grid

